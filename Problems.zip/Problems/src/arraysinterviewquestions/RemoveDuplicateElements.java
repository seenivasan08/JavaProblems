package arraysinterviewquestions;

public class RemoveDuplicateElements {
    public static void main(String[] args){
        int[] nums = {1,2,2,3};
                    //0 1 2 3

        int index = 1;

        for(int i=1; i<nums.length; i++){
            boolean isDuplicate = false;
            for(int j=0; j<index; j++){
                if(nums[i]==nums[j]){
                    isDuplicate = true;
                    break;
                }
            }
            if(!isDuplicate){
                nums[index] = nums[i];
                index++;
            }
        }
        for(int i=0; i<index; i++){
            System.out.print(" "+nums[i]);
        }
    }
}
