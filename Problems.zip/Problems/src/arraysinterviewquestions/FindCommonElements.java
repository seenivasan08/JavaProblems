package arraysinterviewquestions;

public class FindCommonElements {
    public static void main(String[] args){
        int[] arr1 = {10,40,1,8,39,450};
        int[] arr2 = {11,1,39,8,100,450};

        for(int i=0; i<arr1.length; i++){
            for(int j=0; j<arr2.length; j++){
                if(arr1[i]==arr2[j]){
                    System.out.println(arr1[i]);

                }
            }
        }
    }
}
