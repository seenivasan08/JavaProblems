package arraysinterviewquestions;

public class CheckArraysAreEqual {
    public static void main(String[] args){
        int[] arr1 = {2,5,7,6};
        int[] arr2 = {6,5,2,7};

        boolean result = isEqaul(arr1, arr2);
        if(result){
            System.out.print("Both arrays are equal");
        }
        else{
            System.out.print("Both arrays are not equal");
        }
    }

    private static boolean isEqaul(int[] arr1, int[] arr2) {

        if(arr1.length!=arr2.length){
            return false;
        }
        for(int i=0; i<arr1.length-1; i++){
            for(int j=i+1; j<arr1.length; j++){
                if(arr1[i]>arr1[j]){
                    int temp = arr1[i];
                    arr1[i] = arr1[j];
                    arr1[j] = temp;
                }
                if(arr2[i]>arr2[j]){
                    int temp = arr2[i];
                    arr2[i] = arr2[j];
                    arr2[j] = temp;
                }
            }
        }
        for(int i=0; i<arr1.length; i++){
            if(arr1[i]!=arr2[i]) {
                return false;
            }
        }
        return true;


    }
}
