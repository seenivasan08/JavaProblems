package arraysinterviewquestions;

public class FindMaxAndMinElement {
    public static void main(String[] args){

        int[] arr = {10,8,20,30,40,50};

        int largest = arr[0];
        int smallest = arr[0];

        for(int i=0; i<arr.length; i++){
            if(largest < arr[i]){
                largest = arr[i];
            }
            else if(smallest > arr[i]){
                smallest = arr[i];
            }
        }
        System.out.println("Largest number in array: " +largest);
        System.out.println("Smallest number in array: " +smallest);

    }
}
