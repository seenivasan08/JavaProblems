package collectionsinterviewquestions;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

class Employee{
    private String name;
    private int age;
    private int id;
    private String dept;

    public Employee(String name, int age, int id, String dept){
        this.name = name;
        this.age = age;
        this.id = id;
        this.dept = dept;
    }

    public String getDept(){
        return dept;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", id=" + id +
                ", dept='" + dept + '\'' +
                '}';
    }
}
public class EmployeeTest{
    public static void main(String[] args){
        List<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(new Employee("Allamadhev",24,1,"Backend Development"));
        employeeList.add(new Employee("Seenivasan",23,2,"Backend Development"));
        employeeList.add(new Employee("Dinesh Kumar",23,4,"FullStack Development"));
        employeeList.add(new Employee("Vijay",22,5,"Android Development"));


        int countOfBackendDevelopment = 0;
        int countOfFullStackDevelopment =0;
        int countOfAndroidDevelopment =0 ;

        for(Employee employee : employeeList){
            if(employee.getDept().contains("Backend Development")){
                System.out.println(employee);
                countOfBackendDevelopment++;
            }
            if(employee.getDept().contains("FullStack Development")){
                System.out.println(employee);
                countOfFullStackDevelopment++;
            }
            if(employee.getDept().contains("Android Development")){
                System.out.println(employee);
                countOfAndroidDevelopment++;
            }
        }
        System.out.println("Number of Employee there in Backend Development Department: " +countOfBackendDevelopment);

        System.out.println("Number of Employee there in FullStack Development Department: " +countOfFullStackDevelopment);

        System.out.println("Number of Employee there in Android Development Department: " +countOfAndroidDevelopment);

//        Map<String,List<Employee>> groupingByDept = employeeList.stream().collect(Collectors.groupingBy(employee -> employee.getDept()));
//        System.out.print(groupingByDept);
//
//        System.out.println("Number of employees in each department");
//        Map<String, Long> count = employeeList.stream().collect(Collectors.groupingBy(Employee::getDept, Collectors.counting()));
//        System.out.println(count);




    }
}