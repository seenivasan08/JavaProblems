package streamarrayinterviewquestions;

import java.util.Arrays;

public class SumElements {
    public static void main(String[] args){
        int[] arr = {2,3,4,5,7};

        //System.out.print(Arrays.stream(arr).reduce(0, (x,y)->x+y));
        System.out.print(Arrays.stream(arr).sum());
    }
}
