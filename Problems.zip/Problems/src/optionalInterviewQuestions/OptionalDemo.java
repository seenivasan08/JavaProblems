package optionalInterviewQuestions;

import java.util.Optional;

public class OptionalDemo {
    public static void main(String[] args){
        String str = null;
        //String str = "seenivasan";

        Optional<String> optional = Optional.ofNullable(str);

        if(optional.isPresent()) {
            System.out.println("Value is present: " + optional.get());
        }
        else{
            String value = optional.orElse("Default");
            System.out.println("Value is not present: " +value);
        }

        //String str = null;
//        String str = "";
//
//        Optional<String> optional = Optional.of(str);
//
//        if(optional.isPresent()) {
//            System.out.println("Value is present: " + optional.get());
//        }
//        else{
//            String value = optional.orElse("Default");
//            System.out.println("Value is not present: " +value);
//        }
    }
}
