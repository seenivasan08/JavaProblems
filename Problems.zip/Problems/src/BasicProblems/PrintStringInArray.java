package BasicProblems;

import java.util.Scanner;

public class PrintStringInArray {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the string");
//        String str = sc.next();
//        String temp = "";
          String str = "seenivasan";
          String temp = "";
        for(int i=0; i<str.length(); i++){
            temp = temp + str.charAt(i);
        }
        System.out.println(temp);
    }
}
