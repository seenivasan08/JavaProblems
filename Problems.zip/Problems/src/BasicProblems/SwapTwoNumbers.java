package BasicProblems;

import java.util.Scanner;

public class SwapTwoNumbers {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter number a");
//        int a = sc.nextInt();
//        System.out.println("Enter number b");
//        int b = sc.nextInt();
        int a = 10, b = 20;
        int temp;

        temp = a;
        a = b;
        b = temp;
        System.out.println("a is: " +a +"\n"+"b is: "+b);

    }
}
