package BasicProblems;

import java.util.Scanner;

public class SecondLargestNumberInArray {
    public static void main(String[] args){
//        int l1 = Integer.MIN_VALUE;
//        int l2 = Integer.MIN_VALUE;
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the array size:");
//        int t = sc.nextInt();
//        int[] arr = new int[t];
//        System.out.println("Enter the number:");
//        for(int i=0; i<arr.length; i++){
//            arr[i] = sc.nextInt();
//        }
        int l1 = Integer.MIN_VALUE;
        int l2 = Integer.MIN_VALUE;
        int[] arr = {10,20,30,40,50};
        for(int i=0; i<arr.length; i++){
            if(l1<arr[i]){
                l2 = l1;
                l1 = arr[i];
            }
        }
        System.out.print("Second largest number is: "+l2);
    }
}
