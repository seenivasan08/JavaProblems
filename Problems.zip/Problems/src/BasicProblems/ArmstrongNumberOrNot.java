package BasicProblems;

import java.util.Scanner;

public class ArmstrongNumberOrNot {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the number");
//        int n = sc.nextInt();
        int n = 153;
        int sum = 0, r=0, c;
        int temp = n;
        while(n>0){
            r = n%10;
            c = r*r*r;
            sum = sum + c;
            n = n/10;
        }

        if(temp == sum){
            System.out.println("Armstrong Number");
        }
        else{
            System.out.println("Not Armstrong Number");
        }
    }
}
