package BasicProblems;

import java.util.Scanner;

public class ReverseStringInArray {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the string");
//        String str = sc.next();
//        String rev ="";
          String str = "seenivasan";
          String rev = "";
          for(int i=str.length()-1; i>=0; i--){
              rev = rev + str.charAt(i);
          }
          System.out.println("Reverse the string: " +rev);
    }
}
