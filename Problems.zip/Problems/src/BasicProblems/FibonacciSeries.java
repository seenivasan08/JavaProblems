package BasicProblems;

import java.util.Scanner;

public class FibonacciSeries {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the limit");
//        int n = sc.nextInt();
        int n = 7;
        int a =0,b=1,c;
        for(int i=1; i<=n; i++){
            System.out.println(a);
            c = a+b;
            a = b;
            b = c;
        }

    }
}
