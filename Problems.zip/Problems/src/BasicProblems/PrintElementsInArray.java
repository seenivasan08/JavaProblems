package BasicProblems;

import java.util.Scanner;

public class PrintElementsInArray {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter array size");
//        int n = sc.nextInt();
//        int[] arr = new int[n];
//        System.out.println("Enter the numbers");
//        for(int i=0; i<arr.length; i++){
//            arr[i] = sc.nextInt();
//        }
        int[] arr = {10,20,30,40,50};
        for(int i=0; i<arr.length; i++){
            System.out.println(arr[i]);
        }
    }
}
