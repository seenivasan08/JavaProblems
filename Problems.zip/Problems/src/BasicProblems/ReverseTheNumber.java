package BasicProblems;

import java.util.Scanner;

public class ReverseTheNumber {
    public static void main(String[] args){
//        Scanner sc = new Scanner(System.in);
//        System.out.println("Enter the number");
//        int n = sc.nextInt();
        int n = 123;
        int sum = 0, r;
        while(n>0){
            r = n % 10;
            sum = (sum*10)+r;
            n = n/10;
        }
        System.out.println("Reverse the number: "+sum);
    }
}
