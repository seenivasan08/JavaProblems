package streamsinterviewquestions;

import java.util.Arrays;
import java.util.List;

public class CountNoOfOnesAndZeros {
    public static void main(String[] args){
        List<Integer> numbers = Arrays.asList(1,0,1,1,0,1,1,0,1);

        Integer ones = numbers.stream().reduce(0, Integer::sum);
        int zeros = numbers.size() - ones;

        System.out.println("Number of 1s are: "+ones);
        System.out.println("Number of 0s are: "+zeros);
    }
}
