package streamsinterviewquestions;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PrintDuplicateStrings {
    public static void main(String[] args){
        List<String> list = Arrays.asList("Chennai","Chennai","Bangalore","Mumbai");


        Map<String, Long> count = list.stream().filter(word -> Collections.frequency(list, word)>1).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        System.out.println("Prints Duplicate Strings");
        count.entrySet().stream().filter(v -> v.getValue()>1).map(Map.Entry::getKey).forEach(System.out::println);

//        Set<String> set = new HashSet<>();
//        list.stream().filter(s -> !set.add(s)).forEach(System.out::println);

        System.out.println("Prints Distinct Strings");
        list.stream().distinct().forEach(System.out::println);

    }
}
