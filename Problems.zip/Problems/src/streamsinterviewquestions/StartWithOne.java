package streamsinterviewquestions;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StartWithOne {
    public static void main(String[] args){
        List<Integer> list = Arrays.asList(10,50,30,20,11,19);

        List<String> startWithOne = list.stream().map(s -> s +" ").filter(s ->s.startsWith("1")).toList();
        System.out.println(startWithOne);
    }
}
