package streamsinterviewquestions;

import java.util.Arrays;
import java.util.List;

public class PrintStringStartAndEndWithSame {
    public static void main(String[] args){

        List<String> list = Arrays.asList("ab","aba","xyz","mno","xyz","pop");

        list.stream()
                .filter(s -> s.substring(0,1).equals(s.substring(s.length()-1)))
                .forEach(System.out::println);
    }
}
