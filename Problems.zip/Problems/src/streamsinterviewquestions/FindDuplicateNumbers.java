package streamsinterviewquestions;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindDuplicateNumbers {
    public static void main(String[] args){
        List<Integer> numbers = Arrays.asList(10,20,20,25,25,27,27,30);

        Set<Integer> set = new HashSet<>();

        numbers.stream().filter( n -> !set.add(n)).forEach(System.out::println);
    }
}
