package streamsinterviewquestions;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

public class SquareTheNumbers {
    public static void main(String[] args){
        List<Integer> numbers = Arrays.asList(4,5,20,7,10,9);

        //List<Integer> numbers = Arrays.asList(4,5,6,7,8);

        System.out.println("Square of each numbers");
        numbers.stream().map(n->n*n).forEach(System.out::println);

        System.out.println("Prints numbers are greater than or equal to 100 after square of each numbers");
        numbers.stream().map(n->n*n).filter(n->n>=100).forEach(System.out::println);

        System.out.println("Prints average of numbers after greater than or equal to 100");

        OptionalDouble opt = numbers.stream().mapToInt(n->n*n).filter(n->n>=100).average();
        if(opt.isPresent()) {
            System.out.println("Averaging is: " +opt.getAsDouble());
        }
        else{
            System.out.println("No qualifying element");
        }
    }
}
