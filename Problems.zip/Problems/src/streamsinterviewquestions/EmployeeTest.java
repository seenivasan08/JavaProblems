package streamsinterviewquestions;

import java.util.List;
import java.util.ArrayList;

public class EmployeeTest{
    public static void main(String[] args){
        List<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(new Employee("Allamadhev",24,"Chennai"));
        employeeList.add(new Employee("Seenivasan",23,"Madurai"));
        employeeList.add(new Employee("Dinesh Kumar",23,"Chennai"));
        employeeList.add(new Employee("Vijay",22,"Chennai"));

        employeeList.stream().filter(c -> c.getCity().contains("C")).forEach(System.out::println);
        //System.out.println(employeeList.stream().filter(c -> c.getCity().contains("C")).collect(Collectors.toList()));

//        for(Employee employee : employeeList){
//            if(employee.getCity().contains("C")){
//                System.out.println(employee);
//            }
//
//        }



    }
}