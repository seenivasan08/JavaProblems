package stringinterviewquestions;

public class RotationStringDemo {
    public static void main(String[] args){
        String str = "ABCD";
        String rotatedString = "CDAB";

        boolean result = isRotatedString(str, rotatedString);
        System.out.print(result);
    }

    private static boolean isRotatedString(String str, String rotatedString) {
        if(str==null || rotatedString==null){
            return false;
        }
        else if(str.length()!=rotatedString.length()){
            return false;
        }
        else{
            String concatenated = str+str;//ABCDABCD
            return concatenated.contains(rotatedString);
        }
    }
}
