package stringinterviewquestions;

public class Main {
    public static void main(String[] args){
        String s1 = "HELLO";
        String s2 = "HELLO";
        String s3 =  new String("HELLO");
        String s4 = new String("HELLO");
        StringBuffer s5 = new StringBuffer("HELLO");
        StringBuffer s6 = new StringBuffer("HELLO");

        System.out.println(s1 == s2);//true
        System.out.println(s1 == s3); //false
        System.out.println(s1.equals(s2));//true
        System.out.println(s1.equals(s3));//true
        System.out.println(s3 == s4);//false
        System.out.println(s3.equals(s4));//true
        System.out.println(s5.toString()==s6.toString());//false
        System.out.println(s5.equals(s6));//false
        System.out.println(s5.toString().equals(s6.toString()));//true
    }

}
