package stringinterviewquestions;

public class EvenWordDemo {
    public static void main(String[] args){
        String str = "Hell World We Lol";
        String[] words = str.split(" ");
        for(int i=0; i<words.length; i++){
            String s = words[i];
            if(s.length()%2==0){
                System.out.println(s);
            }
        }
    }
}
