package stringinterviewquestions;

public class RemoveCharacter {
    public static void main(String[] args){
        String str = "Seenixxvasanxx";

        char target = 'x';

        char[] ch = str.toCharArray();

        for(int i=0; i<ch.length; i++){
            if(target!=ch[i]){
                System.out.print(ch[i]);
            }
        }
    }
}
