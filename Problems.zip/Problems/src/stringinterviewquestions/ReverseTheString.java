package stringinterviewquestions;

public class ReverseTheString {
    public static void main(String[] args){
        String str = "Seenivasan";
        String rev = "";
        for(int i=str.length()-1; i>=0; i--){
            rev = rev+str.charAt(i);
        }
        System.out.print(rev);
    }
}
