package stringinterviewquestions;

public class Panagrams {
    public static void main(String[] args){

        String s = "abc defGhi JklmnOP QRStuv wxyz";
        s =s.toLowerCase();
        boolean panagram = false;
        if(s.length()<26){
            panagram = false;
        }
        else{
            for(char ch ='a'; ch<='z'; ch++){



                if(s.indexOf(ch)<0){
                    panagram = false;
                }
                else {
                    panagram = true;
                }
            }
        }
        System.out.println(panagram);
    }
}
