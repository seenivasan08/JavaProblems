package stringinterviewquestions;

public class SumStrings {
    public static void main(String[] args){
        String a = "111";
        String b = "333";
        int sum = Integer.parseInt(a) + Integer.parseInt(b);
        System.out.println(sum);
        String str = String.valueOf(sum);
        System.out.print(str);
    }
}
