package stringinterviewquestions;

public class RemoveSpecialCharacters {
    public static void main(String[] args){
        String str = "seeniv@s@n";
        String removedSpecialCharacters = "";

        int count = 0;
        for(int i=0; i<str.length(); i++){

            if(!Character.isDigit(str.charAt(i))&&!Character.isLetter(str.charAt(i))&&!Character.isWhitespace(str.charAt(i))){
                count++;
            }
            else{
                removedSpecialCharacters = removedSpecialCharacters + str.charAt(i);
            }
        }
        System.out.println("Number of special characters there in given String: "+count);
        System.out.println("Removed sepcial characters: "+removedSpecialCharacters);
    }
}
