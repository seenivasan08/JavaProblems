package stringinterviewquestions;

public class CompareStringDemo {
    public static void main(String[] args) {
        String a = "seenivasan";
        String b = "seenivasan";

        char[] a1 = a.toCharArray();
        char[] b1 = b.toCharArray();

        boolean check = false;
        for(int i=0; i<a.length(); i++){
            char ch = a1[i];
            for(int j=0; j<b.length(); j++){
                if(ch == b1[j]){
                    check = true;
                }
                else{
                    check = false;
                }
            }
        }
        if(check){
            System.out.println("Both strings are same");
        }
        else{
            System.out.println("Both strings are not same");
        }
    }
}
