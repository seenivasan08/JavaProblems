package stringinterviewquestions;

public class RemoveDuplicates {
    public static void main(String[] args) {

        String str = "seenivasan";

        char[] ch = str.toCharArray();

        int index = 1;
        for(int i=1; i<ch.length; i++){
            boolean isDuplicate = false;
            for(int j=0; j<index; j++){
                if(ch[i]==ch[j]){
                    isDuplicate = true;
                    break;
                }
            }
            if(!isDuplicate){
                ch[index] = ch[i];
                index++;
            }
        }
        for(int i=0; i<index; i++){
            System.out.print(ch[i]);
        }

    }
}
