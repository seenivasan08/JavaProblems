package stringinterviewquestions;

import java.util.Scanner;

public class CountWordsDemo {
    public static void main(String[] args){
        String str = "abc abc";

        int count = 0;
        if(str.charAt(0)!=' '){
            count++;
        }
        for(int i=0; i<str.length(); i++){
            if(str.charAt(i)==' ' && str.charAt(i+1)!=' '){
                count++;
            }
        }
        System.out.println("Count Number of Words are: " +count);
    }
}
