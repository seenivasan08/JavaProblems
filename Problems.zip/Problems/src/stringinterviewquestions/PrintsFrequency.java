package stringinterviewquestions;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class PrintsFrequency {
    public static void main(String[] args){
        String s = "Seenivasan S R";

           printsFrequency(s);

        }

    private static void printsFrequency(String str) {

        Map<Character, Integer> counts = new HashMap<>();

        for(int i=0; i<str.length(); i++){
            char c = str.charAt(i);

            if(Character.isLetter(c)){

                counts.put(c, counts.getOrDefault(c, 0)+1);
            }

        }
        Map<Character,Integer> sortedCounts = new TreeMap<>(counts);

        for(Map.Entry<Character,Integer> entry : sortedCounts.entrySet()){
            System.out.println(entry.getKey()+"="+entry.getValue());
        }

    }
}

