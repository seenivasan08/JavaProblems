package stringinterviewquestions;

public class FirstNonRepeatedCharacter {
    public static void main(String[] args){
        String s = "seenivasan";

        boolean found = false;
        for(int i=0; i<s.length(); i++){

            char ch = s.charAt(i);
            boolean repeat = false;
            for(int j=0; j<s.length(); j++){

                if(i!=j && ch == s.charAt(j)){
                    repeat = true;
                    break;
                }
            }
            if(!repeat){
                System.out.println(ch +" is first non repeated character");
                found = true;
                break;
            }

        }
        if(!found){
            System.out.println("Not found non first repeated character");
        }
    }
}
