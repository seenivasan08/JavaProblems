package stringinterviewquestions;

public class CountCharacters {
    public static void main(String[] args){
        String str = "Hello World";
        String[] words = str.split(" ");
        for(int i=0; i< words.length; i++){
            String s = words[i];
            System.out.println(s +"->" +s.length());
        }
    }
}
