package stringinterviewquestions;

public class PalindromStringDemo {
    public static void main(String[] args){
        String str = "amma";
        String rev = "";
        for(int i=str.length() - 1; i>=0; i--){
            rev = rev + str.charAt(i);
        }

        if(str.equals(rev)){
            System.out.println("Given string is Palindrome");
        }
        else{
            System.out.print("Given string is not Palindrome");
        }
    }
}
