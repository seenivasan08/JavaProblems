package stringinterviewquestions;

public class StringEqualsAndDoubleEqaulsOperator {

    public static void main(String[] args){
        String str1 = "Abc"; // It is a literal where this will be created in a string pool
        String str2 = "Abc";
        String str3 = new String("Abc");//It is creating new object where this will be created in a heap
        String str4 = new String("abc");
        System.out.println(str1==str2);//true
        System.out.println(str1==str3);//false
        System.out.println(str1.equals(str3));//true
        System.out.println(str1.equals(str4));//false
        System.out.print(str1.equalsIgnoreCase(str4));//true

    }
}
