package stringinterviewquestions;

public class Anagram {
    public static void main(String[] args){
        String a = "aab";
        String b = "baa";

        char[] a1 = a.toCharArray();
        char[] b1 = b.toCharArray();
        int count = 0; boolean anagram = false;
        for (int j = 0; j < b1.length; j++) {
            char ch = b1[j];
            for (int i = 0; i < a1.length; i++) {
                if (ch == a1[i]) {
                    a1[i] = '\n';
                    count++;
                    break;
                }
            }
        }
        if(count==b.length()){
            System.out.print("Anagram");
            anagram = true;
        }

        if(!anagram){
            System.out.print("Not Anagram");
        }

    }
}
//import java.util.Arrays;
//class Anagram{
//    public static void main(String[] args){
//        String a = "aab";
//        String b = "baa";
//        char[] a1 = a.toCharArray();
//        char[] b1 = b.toCharArray();
//
//        Arrays.sort(a1);
//        Arrays.sort(b1);
//
//        System.out.println(a1);
//        System.out.println(b1);
//
//        if(Arrays.equals(a1,b1)){
//            System.out.println("Anagram");
//        }
//        else{
//            System.out.println("Not Anagram");
//        }
//
//
//    }
//}