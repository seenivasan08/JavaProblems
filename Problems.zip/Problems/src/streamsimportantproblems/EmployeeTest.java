package streamsimportantproblems;

import java.util.*;
import java.util.stream.Collectors;

class Employee{
    private int id;
    private String name;
    private int age;
    private String dept;
    private double salary;

    public Employee(int id, String name, int age, String dept, double salary){
        this.id = id;
        this.name = name;
        this.age = age;
        this.dept = dept;
        this.salary = salary;
    }

    public String getName(){
        return name;
    }
    public String getDept(){
        return dept;
    }
    public double getSalary(){
        return salary;
    }
    public void setSalary(double salary){
        this.salary = salary;
    }
    public int getAge(){
        return age;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", dept='" + dept + '\'' +
                ", salary=" + salary +
                '}';
    }
}
public class EmployeeTest {
    public static void main(String[] args){
        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee(101, "Siva", 35, "Sales", 30000));
        employeeList.add(new Employee(102,"Bala",42,"HR",42000));
        employeeList.add(new Employee(103, "Ramesh", 23, "Development", 20000));
        employeeList.add(new Employee(104, "Devi", 54,"Sales",48000));
        employeeList.add(new Employee(105, "Ramya",25,"Development",22000));

        printEmployees(employeeList);
        checkSalary(employeeList);
        printEmployeeNames(employeeList);
        highestSalaryEmployee(employeeList);
        minimumSalaryEmployee(employeeList);
        removeDuplicateDepartments(employeeList);
        sortEmployees(employeeList);
        sortEmployeesReverse(employeeList);
        sortEmployeesTwo(employeeList);
        printEmployeesDepartmentWise(employeeList);
        printNumberOfEmployees(employeeList);
        printDuplicateDepartments(employeeList);
        printEmployeeBasedOnSalary(employeeList);
        fetchTopThreeSalariedEmployees(employeeList);
        printEmployeeSalaryLessThanThirdHighestSalary(employeeList);
        printThirdHighestSalaryEmployee(employeeList);
        printAverageAgeOfEachDepartment(employeeList);
        printIncrementSalary(employeeList);
        printEmployeesDeptWiseBasedOnMaxSalary(employeeList);


        

    }




    //print the employees list using stream
    private static void printEmployees(List<Employee> employeeList) {
        System.out.println("Printing the employees list using stream");
        employeeList.stream().forEach(System.out::println);
    }

    //find the employee whose salary greater than 40000
    private static void checkSalary(List<Employee> employeeList) {
        System.out.println("The employees whose salary greater than 40000");
        employeeList.stream().filter(employee -> employee.getSalary()>40000).map(Employee::getName).forEach(System.out::println);
    }

    //print the names of employees in sales department
    private static void printEmployeeNames(List<Employee> employeeList) {
        System.out.println("Print the names of employees in sales department");
        employeeList.stream().filter(employee -> employee.getDept().equals("Sales")).map(employee -> employee.getName()).forEach(System.out::println);
    }

    //print the name of the highest salary employee
    private static void highestSalaryEmployee(List<Employee> employeeList) {
        System.out.println("The name of the highest salary employee");
        String maxSalaryEmployee = employeeList.stream().max(Comparator.comparing(Employee::getSalary)).map(Employee::getName).get();
        System.out.println(maxSalaryEmployee);
    }

    //print the name of the minimum salary employee
    private static void minimumSalaryEmployee(List<Employee> employeeList) {
        System.out.println("The name of the minimum salary employee");
        String minSalaryEmployee = employeeList.stream().min(Comparator.comparing(Employee::getSalary)).map(Employee::getName).get();
        System.out.println(minSalaryEmployee);
    }

    //remove the duplicate departments/print the unique departments
    private static void removeDuplicateDepartments(List<Employee> employeeList) {
        System.out.println("The unique departments are");

        String uniqueDepartments = employeeList.stream().map(Employee::getDept).distinct().collect(Collectors.joining(", "));
        System.out.println(uniqueDepartments);

    }

    //sort the employees based on name
    private static void sortEmployees(List<Employee> employeeList) {
        System.out.println("Sorting the employees based on name");
        employeeList.stream().map(Employee::getName).sorted().forEach(System.out::println);
    }

    //sort the employees based on name in reverse order
    private static void sortEmployeesReverse(List<Employee> employeeList) {
        System.out.println("Sorting the employees based on name in reverse order");
        employeeList.stream().map(Employee::getName).sorted(Comparator.reverseOrder()).forEach(System.out::println);
    }

    //sort the employees based on department and name
    private static void sortEmployeesTwo(List<Employee> employeeList){
        System.out.println("Sorting the employees based on department and name");
        employeeList.stream().sorted(Comparator.comparing(Employee::getDept).thenComparing(Employee::getName)).forEach(System.out::println);

    }

    //print the number of employees in each department
    private static void printNumberOfEmployees(List<Employee> employeeList) {
        System.out.println("print the number of employees in each department");
        Map<String, Long> numberOfEmployees = employeeList.stream().collect(Collectors.groupingBy(Employee::getDept,Collectors.counting()));
        System.out.println(numberOfEmployees);
    }

    //print the duplicate departments
    private static void printDuplicateDepartments(List<Employee> employeeList) {
        System.out.println("print the duplicate departments");
        Map<String, Long> numberOfEmployees = employeeList.stream().collect(Collectors.groupingBy(Employee::getDept, Collectors.counting()));
        numberOfEmployees.entrySet().stream().filter(dept -> dept.getValue()>1).map(employee -> employee.getKey()).forEach(System.out::println);
    }

    //print employees department wise
    private static void printEmployeesDepartmentWise(List<Employee> employeeList) {

        System.out.println("Prints the employees department wise");
        Map<String, List<Employee>> groupingByDept = employeeList.stream().collect(Collectors.groupingBy(Employee::getDept));
        System.out.println(groupingByDept);
    }

    //print employee based on their salary in desc order
    private static void printEmployeeBasedOnSalary(List<Employee> employeeList){
        System.out.println("Prints the employees based on their salary in desc order");
        System.out.println(employeeList.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).collect(Collectors.toList()));

    }

    //fetch top three salaried employees
    private static void fetchTopThreeSalariedEmployees(List<Employee> employeeList){
        System.out.println("Fetch top three salaried employees");
        System.out.println(employeeList.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).limit(3).collect(Collectors.toList()));
    }

    //fetch all employees having salary less than 3rd highest salary
    private static void printEmployeeSalaryLessThanThirdHighestSalary(List<Employee> employeeList){
        System.out.println("Fetch all employees having salary less than 3rd highest salary");
        System.out.println(employeeList.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).skip(3).collect(Collectors.toList()));
    }

    //prints 3rd highest salary employee
    private static void printThirdHighestSalaryEmployee(List<Employee> employeeList){
        System.out.println("Prints 3rd highest salary employee");
        System.out.println(employeeList.stream().sorted(Comparator.comparing(Employee::getSalary).reversed()).skip(2).limit(1).collect(Collectors.toList()));
    }

    //prints average age of each department
    private static void printAverageAgeOfEachDepartment(List<Employee> employeeList){
        System.out.println("Prints average of each department");
        Map<String, Double> avg = employeeList.stream().collect(Collectors.groupingBy(Employee::getDept, Collectors.averagingDouble(Employee::getAge)));
        System.out.println(avg);
    }

    //prints incremented salary whose above age 25
    private static void printIncrementSalary(List<Employee> employeeList){
        System.out.println("Incremented salary");
        List<Employee> incrementedSalary = employeeList.stream().map(e -> {
            if(e.getAge()>25){
                e.setSalary(e.getSalary()*1.10);
            }
            return e;
        }).collect(Collectors.toList());

        System.out.println(incrementedSalary);
    }

    //print employees each department based on maximum salary
    private static void printEmployeesDeptWiseBasedOnMaxSalary(List<Employee> employeeList){
        System.out.println("Print employees each department based on maximum salary");

        Map<String, Employee> eachDept = employeeList.stream()
                .collect(Collectors.groupingBy(Employee::getDept, Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)), Optional::get)));
        System.out.println(eachDept);

    }





};
